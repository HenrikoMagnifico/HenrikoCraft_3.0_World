    
function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}

EntityEvents.spawned(event => {
    let entity = event.entity
    if (event.level.getLunarContext() === null) return
    const event_string = event.level.getLunarContext().getLunarForecast().getCurrentEventRaw().key().location().toString()
    //if (entity.type == 'minecraft:cod' && event_string === "enhancedcelestials:blood_moon") {
    //    event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon drowned ~ ~ ~ {CanBreakDoors:1b,HandItems:[{id:"minecraft:trident",Count:1b,tag:{Unbreakable:1b}},{}],HandDropChances:[0.000F,0.085F]}`)
    //    event.cancel()
    //}
    if (entity.type == 'minecraft:enderman' && entity.level.canSeeSky(entity.blockPosition()) && event_string === "enhancedcelestials:blood_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon skeleton_horse ~ ~ ~ {SkeletonTrap:1b}`)
        event.cancel()
    }
})