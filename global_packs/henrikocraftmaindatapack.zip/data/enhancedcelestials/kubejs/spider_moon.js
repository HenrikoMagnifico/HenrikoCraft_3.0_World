    
function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}

EntityEvents.spawned(event => {
    let entity = event.entity
    if (event.level.getLunarContext() === null) return
    const event_string = event.level.getLunarContext().getLunarForecast().getCurrentEventRaw().key().location().toString()
    if (entity.type == 'minecraft:zombie' && event_string === "enhancedcelestials:spider_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon spider`)
        event.cancel()
    }
    if (entity.type == 'minecraft:skeleton' && event_string === "enhancedcelestials:spider_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon cave_spider`)
        event.cancel()
    }
    if (entity.type == 'minecraft:creeper' && event_string === "enhancedcelestials:spider_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon cave_spider`)
        event.cancel()
    }
    if (entity.type == 'minecraft:enderman' && event_string === "enhancedcelestials:spider_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon cave_spider ~ ~ ~ {ActiveEffects:[{Id:14,Amplifier:0b,Duration:-1,ShowParticles:0b}]}`)
        event.cancel()
    }
    if (entity.type == 'minecraft:zombie_villager' && event_string === "enhancedcelestials:spider_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon alexsmobs:centipede_head`)
        event.cancel()
    }
    if (entity.type == 'minecraft:husk' && event_string === "enhancedcelestials:spider_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon alexsmobs:crimson_mosquito`)
        event.cancel()
    }
})