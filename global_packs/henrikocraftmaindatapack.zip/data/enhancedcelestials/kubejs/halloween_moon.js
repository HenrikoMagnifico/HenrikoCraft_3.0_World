    
function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}

EntityEvents.spawned(event => {
    let entity = event.entity
    if (event.level.getLunarContext() === null) return
    const event_string = event.level.getLunarContext().getLunarForecast().getCurrentEventRaw().key().location().toString()
    if (entity.type == 'minecraft:zombie' && event_string === "enhancedcelestials:halloween_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon zombie ~ ~ ~ {Silent:1b,ArmorItems:[{},{},{},{id:"minecraft:jack_o_lantern",Count:1b}],ActiveEffects:[{Id:14,Amplifier:0b,Duration:-1,ShowParticles:0b}]}`)
        event.cancel()
    }
})