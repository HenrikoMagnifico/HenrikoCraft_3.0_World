    
function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}

EntityEvents.spawned(event => {
    let entity = event.entity
    if (event.level.getLunarContext() === null) return
    const event_string = event.level.getLunarContext().getLunarForecast().getCurrentEventRaw().key().location().toString()
    if (entity.type == 'minecraft:illusioner' && entity.level.canSeeSky(entity.blockPosition()) && event_string === "enhancedcelestials:super_blood_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon wither_skeleton ~ ~ ~ {DeathLootTable:"empty",HandItems:[{id:"minecraft:bow",Count:1b,tag:{Unbreakable:1b}},{}],HandDropChances:[0.000F,0.085F]}`)
        event.cancel()
    }
    if (entity.type == 'minecraft:enderman' && entity.level.canSeeSky(entity.blockPosition()) && event_string === "enhancedcelestials:super_blood_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon creeper ~ ~ ~ {powered:1b}`)
        event.cancel()
    }
    if (entity.type == 'minecraft:zombie_villager' && entity.level.canSeeSky(entity.blockPosition()) && event_string === "enhancedcelestials:super_blood_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon ravager ~ ~ ~ {PatrolLeader:0b,Patrolling:0b,CanJoinRaid:0b,Passengers:[{id:"minecraft:pillager",PatrolLeader:0b,Patrolling:0b,CanJoinRaid:0b,HandItems:[{id:"minecraft:crossbow",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"minecraft:multishot",lvl:3s},{id:"minecraft:quick_charge",lvl:3s}],ChargedProjectiles:[{id:"minecraft:arrow",Count:1b},{},{}],Charged:1b}},{}],HandDropChances:[0.000F,0.085F]}],ActiveEffects:[{Id:2,Amplifier:0b,Duration:-1,ShowParticles:0b}]}`)
        event.cancel()
    }
    if (entity.type == 'minecraft:cave_spider' && entity.level.canSeeSky(entity.blockPosition()) && event_string === "enhancedcelestials:super_blood_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon vindicator ~ ~ ~ {DeathLootTable:"empty",PatrolLeader:0b,Patrolling:0b,CanJoinRaid:0b,HandItems:[{id:"minecraft:netherite_axe",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"minecraft:sharpness",lvl:5s}]}},{}],HandDropChances:[0.000F,0.085F],ActiveEffects:[{Id:1,Amplifier:1b,Duration:-1,ShowParticles:0b}]}`)
        event.cancel()
    }
})


