    
function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}

EntityEvents.spawned(event => {
    let entity = event.entity
    if (event.level.getLunarContext() === null) return
    const event_string = event.level.getLunarContext().getLunarForecast().getCurrentEventRaw().key().location().toString()
    if (entity.type == 'minecraft:enderman' && entity.level.canSeeSky(entity.blockPosition()) && event_string === "enhancedcelestials:halloween_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon lightning_bolt ~ ~ ~`)
        event.cancel()
    }
    if (entity.type == 'minecraft:enderman' && event_string === "enhancedcelestials:halloween_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon enderman ~ ~ ~ {AngerTime:999999}`)
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run execute as @e[type=minecraft:enderman,limit=4,sort=nearest] at @s run data modify entity @s AngryAt set from entity @p UUID`)
        event.cancel()
    }
    if (entity.type == 'minecraft:creeper' && entity.level.canSeeSky(entity.blockPosition()) && event_string === "enhancedcelestials:halloween_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon zombified_piglin ~ ~ ~ {DeathLootTable:"empty",HandItems:[{id:"minecraft:netherite_sword",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"minecraft:fire_aspect",lvl:3s}]}},{}],HandDropChances:[0.000F,0.000F],ArmorItems:[{id:"minecraft:golden_boots",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"minecraft:protection",lvl:5s}]}},{id:"minecraft:golden_leggings",Count:1b,tag:{display:{Name:'{"text":"Arcane Fire Leggings","color":"#FF6F00","bold":true}',Lore:['[{"text":"Limited Halloween 2024 item","color":"#8A20C7","bold":true},{"text":" ⭐","color":"yellow","bold":true}]']},Unbreakable:1b,Enchantments:[{id:"minecraft:protection",lvl:2s},{id:"minecraft:fire_protection",lvl:5s},{id:"majruszsenchantments:incompatibility_curse",lvl:1s}]}},{id:"minecraft:golden_chestplate",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"minecraft:protection",lvl:5s}]}},{id:"minecraft:golden_helmet",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"minecraft:protection",lvl:5s}]}}],ArmorDropChances:[0.000F,0.001F,0.000F,0.000F]}`)
        event.cancel()
    }
    if (entity.type == 'minecraft:witch' && entity.level.canSeeSky(entity.blockPosition()) && event_string === "enhancedcelestials:halloween_moon") {
        event.server.runCommandSilent(`execute in ${entity.level.dimension} positioned ${entity.x} ${entity.y} ${entity.z} run summon witch ~ ~ ~ {DeathLootTable:"empty",ArmorItems:[{id:"minecraft:splash_potion",Count:1b,tag:{display:{Name:'{"text":"Super Blue Moon in a Flask","color":"#0091FF","bold":true}',Lore:['[{"text":"Limited Halloween 2024 item","color":"#8A20C7","bold":true},{"text":" ⭐","color":"yellow"}]']},CustomPotionEffects:[{Id:26,Amplifier:4b,Duration:12000}],CustomPotionColor:65297}},{id:"minecraft:splash_potion",Count:1b,tag:{display:{Name:'{"text":"Elixir of Strength","color":"#A60000","bold":true}',Lore:['[{"text":"Limited Halloween 2024 item","color":"#8A20C7","bold":true},{"text":" ⭐","color":"yellow","bold":true}]']},CustomPotionEffects:[{Id:2,Amplifier:1b,Duration:12000},{Id:5,Amplifier:2b,Duration:12000}],CustomPotionColor:13338623}},{id:"minecraft:splash_potion",Count:1b,tag:{display:{Name:'{"text":"Flask of the Phoenix","color":"#FFBD24","bold":true}',Lore:['{"text":"Limited Halloween 2024 item","color":"#8A20C7","bold":true}']},HideFlags:1,Enchantments:[{}],CustomPotionEffects:[{Id:11,Amplifier:0b,Duration:6000},{Id:12,Amplifier:0b,Duration:18000}],CustomPotionColor:16760683}},{id:"minecraft:splash_potion",Count:1b,tag:{display:{Name:'{"text":"Tonic of Haste","color":"#70FFFF","bold":true}',Lore:['{"text":"Limited Halloween 2024 item","color":"#8A20C7","bold":true}']},HideFlags:1,Enchantments:[{}],CustomPotionEffects:[{Id:1,Amplifier:2b,Duration:36000},{Id:3,Amplifier:4b,Duration:36000},{Id:17,Amplifier:4b,Duration:36000},{Id:18,Amplifier:1b,Duration:36000}],CustomPotionColor:12775935}}],ArmorDropChances:[0.000F,0.000F,0.010F,0.000F]}`)
        event.cancel()
    }
})